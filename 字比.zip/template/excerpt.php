<?php
/**
 * Used for index/archive/search/author/catgory/tag.
 *
 */

zib_posts_list();
